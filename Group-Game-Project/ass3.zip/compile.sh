#!/bin/sh

PROGRAM_NAME=GameApp.java
cd src
javac $PROGRAM_NAME

if [ $? -eq 0 ]
then
    echo "compile worked!"
fi
