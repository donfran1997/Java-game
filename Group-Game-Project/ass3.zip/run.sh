#!/bin/sh

PROGRAM_NAME=GameApp
cd src
java $PROGRAM_NAME

if [ $? -eq 0 ]
then 
    echo "run worked!"
fi
